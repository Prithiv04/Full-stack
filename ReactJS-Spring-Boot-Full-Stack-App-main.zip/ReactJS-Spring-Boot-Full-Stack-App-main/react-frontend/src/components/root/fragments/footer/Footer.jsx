import React from "react";


const Footer = (props) => {
  return (
    <footer className={props.class}>
      &copy; Hobbie 2022. All rights reserved.
    </footer>
  );
};

export default Footer;
