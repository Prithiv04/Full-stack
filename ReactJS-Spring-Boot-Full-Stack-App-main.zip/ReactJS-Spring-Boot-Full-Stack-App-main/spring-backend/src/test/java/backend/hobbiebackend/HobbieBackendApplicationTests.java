package backend.hobbiebackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HobbieBackendApplicationTests {
    @Test
    void contextLoads() {
    }
}
