package backend.hobbiebackend.model.entities.enums;

public enum UserRoleEnum {
    ADMIN, USER, BUSINESS_USER;
}
