package backend.hobbiebackend.model.entities.enums;

public enum LocationEnum {
    ZURICH, BERN, LUZERN, ZUG
}
